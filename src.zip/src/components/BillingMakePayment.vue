<template>
  <div class="vehicles-and-trailers container-fluid">
	    <div class="card mb-5">
	      	<div class="card-body coverage-block">
	        	<h4 class="card-title form-sub-title mb-4">Make Payment</h4>
	        </div>
	    </div>
	</div>
</template>

<script>
export default {
  name: 'BillingMakePayment'
};
</script>

<style lang="scss" scoped></style>

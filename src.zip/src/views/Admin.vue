<template>
  <router-view />
</template>

<script>
export default {
  name: 'AdminView'
};
</script>

<style lang="scss" scoped></style>
